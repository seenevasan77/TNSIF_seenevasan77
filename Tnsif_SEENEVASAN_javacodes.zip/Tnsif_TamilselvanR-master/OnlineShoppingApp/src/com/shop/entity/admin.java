package com.shop.entity;

public class admin extends user {
    public admin(int userId, String username, String email) {
        super(userId, username, email);
    }
}
