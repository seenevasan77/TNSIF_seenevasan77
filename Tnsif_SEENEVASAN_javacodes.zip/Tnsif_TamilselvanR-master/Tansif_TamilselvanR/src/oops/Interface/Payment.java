package oops.Interface;

public interface Payment {
	void pay(double amount);
}
