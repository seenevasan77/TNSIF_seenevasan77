package lambda;

public interface demo {
	int factorial(int num);
}
