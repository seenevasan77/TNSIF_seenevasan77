package lambda;

@FunctionalInterface
public interface Operations {
	float performArithmetic(int a, int b);
}
