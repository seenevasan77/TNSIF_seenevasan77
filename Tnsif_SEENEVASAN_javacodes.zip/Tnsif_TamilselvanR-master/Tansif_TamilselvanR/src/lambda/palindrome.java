package lambda;

public interface palindrome<T> {
	boolean checkPalindrome(T data);
}

