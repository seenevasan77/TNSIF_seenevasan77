package day3.assessment1;
public class Productdemo {
    public static void main(String[] args) {
        Product p1 = new Product(101, "Laptop", 55000.0, 5);
        Product p2 = new Product(102, "Smartphone", 25000.0, 10);
        Product p3 = new Product(103, "Headphones", 1500.0, 20);

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
        
    }
}
