package basic;

public class demo {
	public static void main(String[] args) {
		System.out.println("hello world");
		int a=100;
		System.out.println(a);
		System.out.println("good morning");
	}
}
