package basic;

public class ForLoopDemo {
	public static void main(String[] args) 
	{	
		for(int i = 1; i<=1000 ; i++)   //(int i = 1000; i<=1;i--)
		{	
			System.out.print("Value of i:");
			System.out.println(i);
		}
	}
}

