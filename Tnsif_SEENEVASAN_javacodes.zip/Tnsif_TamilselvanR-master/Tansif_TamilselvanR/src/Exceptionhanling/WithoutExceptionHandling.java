package Exceptionhanling;

public class WithoutExceptionHandling {
	public static void main(String[] arg) {
	System.out.println("the programs continues");
	int data=100/0;
}
}